<?php
/************* Database code here*************/
$teacher_id;

$t_name="Akash Jadhav";
$subject="TOC";
$year="TE";
$branch="Computer";
$division="IV";
$roll_count="80";
$present_feedback="70";
$date="20-10-2018";

$low_vc=11;
$prep=3;
$expl=44;
$presentation=2;
$interaction=5;
$punctual=7;
$syll_coverage=10;
$speed=30;
$english=20;

/**************Calculation here*****************/
$final_score="70%";

?>


<?php

/************* PDF code here*************/

require('fpdf.php');

$pdf = new FPDF();
$pdf->AddPage();
$title=$t_name.' - '.$year.' - '.$division;
$pdf->SetTitle($title);


/* Header */
$pdf->SetFont('Arial','B',25);
$pdf->Cell(0,10,'Quality Assessment Program',0,1,'C');

$pdf->SetFont('Arial','B',15);
$pdf->Cell(0,10,'For',0,1,'C');

$pdf->SetFont('Arial','B',20);
$pdf->Cell(0,10,'Engineering/Management/Pharmacy Institutes',0,1,'C');

$pdf->SetFont('Arial','B',15);
$pdf->Cell(0,10,'Of',0,1,'C');

$pdf->SetFont('Arial','B',25);
$pdf->Cell(0,10,'STES/SPSPM/SSPM/YCSPM',0,1,'C');


/* Line */
$pdf->SetLineWidth(0.5);
$pdf->SetDrawColor(0,0,0);
$pdf->Line(10,65,200,65);


/* Information */
$pdf->SetFont('Arial','',16);

$pdf->Cell(90,30,'College : SKNCOE, Pune',0);
$pdf->Cell(100,30,'Feedback for : Prof. '.$t_name,0);
$pdf->Ln();

$pdf->Cell(90,-10,'Year : '.$year,0);
$pdf->Cell(100,-10,'Subject : '.$subject,0);
$pdf->Ln();

$pdf->Cell(90,30,'Branch : '.$branch,0);
$pdf->Cell(100,30,'Division : '.$division,0);
$pdf->Ln();

$pdf->Cell(90,-10,'Roll Count : '.$roll_count,0);
$pdf->Cell(100,-10,'Total feedback : '.$present_feedback,0);
$pdf->Ln();

$pdf->Cell(90,30,'Date : '.$date,0);
$pdf->Ln();


/* Line */
$pdf->Line(10,125,200,125);


/* Score */
$pdf->SetFont('Arial','',16);

$pdf->Cell(60,30,'Low Voice :',0);
$pdf->Cell(30,30,$low_vc.' / '.$present_feedback,0);
$pdf->Cell(70,30,'Preparation :',0);
$pdf->Cell(30,30,$prep.' / '.$present_feedback,0);
$pdf->Ln();

$pdf->Cell(60,-10,'Explanation : ',0);
$pdf->Cell(30,-10,$expl.' / '.$present_feedback,0);
$pdf->Cell(70,-10,'Presentation : ',0);
$pdf->Cell(30,-10,$presentation.' / '.$present_feedback,0);
$pdf->Ln();

$pdf->Cell(60,30,'Interaction : ',0);
$pdf->Cell(30,30,$interaction.' / '.$present_feedback,0);
$pdf->Cell(70,30,'Punctuality : ',0);
$pdf->Cell(30,30,$punctual.' / '.$present_feedback,0);
$pdf->Ln();

$pdf->Cell(60,-10,'Syllabus Coverage : ',0);
$pdf->Cell(30,-10,$syll_coverage.' / '.$present_feedback,0);
$pdf->Cell(70,-10,'Teaching Speed : ',0);
$pdf->Cell(30,-10,$speed.' / '.$present_feedback,0);
$pdf->Ln();

$pdf->Cell(60,30,'English : ',0);
$pdf->Cell(30,30,$english.' / '.$present_feedback,0);
$pdf->Ln();


/* Line */
$pdf->Line(10,200,200,200);


/* Tptal Score */
$pdf->SetFont('Arial','B',25);
$pdf->Cell(0,32,'Total Score : '.$final_score,0,1,'C');


/* Line */
$pdf->Line(10,230,200,230);

$pdf->Output();
?>